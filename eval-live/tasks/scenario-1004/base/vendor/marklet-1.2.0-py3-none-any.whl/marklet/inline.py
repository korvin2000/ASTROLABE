"""Inline level: `code`, **strong**, *emphasis* and [links](url)."""

import html
import re

_CODE = re.compile(r"`([^`]+)`")
_STRONG = re.compile(r"\*\*(.+?)\*\*")
_EM = re.compile(r"(?<![*\w])\*(?!\s)(.+?)(?<!\s)\*(?![*\w])")
_LINK = re.compile(r"\[([^\]]+)\]\(([^)\s]+)\)")
_SAFE_SCHEMES = ("http://", "https://", "mailto:", "/", "#")


def _href(url):
    return url if url.lower().startswith(_SAFE_SCHEMES) else "#"


def render_inline(text, escape_html):
    codes = []

    def keep_code(match):
        codes.append("<code>" + html.escape(match.group(1), quote=False) + "</code>")
        return f"\x00{len(codes) - 1}\x00"

    text = _CODE.sub(keep_code, text)
    if escape_html:
        text = html.escape(text, quote=False)
    text = _LINK.sub(lambda m: f'<a href="{html.escape(_href(m.group(2)))}">{m.group(1)}</a>', text)
    text = _STRONG.sub(r"<strong>\1</strong>", text)
    text = _EM.sub(r"<em>\1</em>", text)
    return re.sub("\x00(\\d+)\x00", lambda m: codes[int(m.group(1))], text)
