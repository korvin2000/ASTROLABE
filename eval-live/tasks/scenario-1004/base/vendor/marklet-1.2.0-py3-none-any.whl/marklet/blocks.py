"""Block level: headings (`#` to `######`), bullet lists (`- ` or `* `) and paragraphs separated by blank lines."""

import re

from marklet.inline import render_inline

_HEADING = re.compile(r"^(#{1,6})\s+(.*?)\s*#*\s*$")
_BULLET = re.compile(r"^[-*]\s+(.*)$")


def render_blocks(text, escape_html):
    out = []
    paragraph = []
    items = []

    def flush():
        if paragraph:
            out.append("<p>" + render_inline(" ".join(paragraph), escape_html) + "</p>")
            paragraph.clear()
        if items:
            out.append("<ul>" + "".join("<li>" + render_inline(i, escape_html) + "</li>" for i in items) + "</ul>")
            items.clear()

    for raw in text.split("\n"):
        line = raw.strip()
        if not line:
            flush()
            continue
        heading = _HEADING.match(line)
        if heading:
            flush()
            level = len(heading.group(1))
            out.append(f"<h{level}>" + render_inline(heading.group(2), escape_html) + f"</h{level}>")
            continue
        bullet = _BULLET.match(line)
        if bullet:
            if paragraph:
                flush()
            items.append(bullet.group(1))
            continue
        if items:
            flush()
        paragraph.append(line)
    flush()
    return "\n".join(out)
