"""marklet: a small Markdown renderer (headings, paragraphs, lists, emphasis, code, links).

    >>> marklet.render("# Title\n\nSome *text*.")
    '<h1>Title</h1>\n<p>Some <em>text</em>.</p>'

Raw HTML in the source passes through unchanged unless `escape_html=True` is given, which shows it as text.
"""

from marklet.blocks import render_blocks

__version__ = "1.2.0"
__all__ = ["render", "__version__"]


def render(text, *, escape_html=False):
    """Renders Markdown `text` to an HTML fragment (blocks joined by newlines, no trailing newline)."""
    if not isinstance(text, str):
        raise TypeError("marklet.render takes a str")
    return render_blocks(text.replace("\r\n", "\n"), escape_html)
